package bridge.domain;

/**
 * The color of the card, only two types.
 */
public enum CardColor {
    BLACK,
    RED
}
